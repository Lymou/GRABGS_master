function x=cgls(A,r,x)
    % input A: 输入矩阵
    % input r:输入残差
    % input x:初始化向量 x0
    % output x: 迭代向量 xk
    p = A.' * r;
    s = p;
    gama = norm(s)^2;
    q = A * p;
    alpha = gama / norm(q)^2;
    x = x + alpha * p;
    r = r - alpha * q;
    s = A.' * r;
    gama1 = norm(s)^2;
    beta = gama1 / gama;
    p = s + beta * p;
    gama = gama1;
end