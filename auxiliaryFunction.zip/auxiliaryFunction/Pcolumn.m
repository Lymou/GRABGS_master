function T=Pcolumn(tau,n)
    t=floor(n/tau);
    if t<n/tau
        t=t+1;
    else
        t=t;
    end
    T=cell(1,t);
    if t>1
    for j=1:t-1
        v=[];
        for k=1:tau
            tmp=(j-1)*tau+k;
            v=[v;tmp];
        end
        T{j}=v;
    end
    T{t}=sort([n:-1:T{t-1}(end)+1].');
    else 
        T{t}=1:n;
    end
end
