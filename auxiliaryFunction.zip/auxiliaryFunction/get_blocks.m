function rows=get_blocks(A,alpha,threshould)
[m,n]=size(A);
for j=1:n
    A2(j)=norm(A(:,j))^2;
end
A2_max=find(A2==max(A2));
A2_max=A2_max(1);
corr_row=size(n,1);
for i=1:n
    corr_row(i)=abs(A(:,i).'*A(:,A2_max))/(norm(A(:,i))*norm(A(:,A2_max)));
end
corr_row(A2_max)=mean(corr_row);
matrix=[1,1;n,1];
vector=[min(corr_row);max(corr_row)];
Sol=inv(matrix)*vector;
row_compress=Sol(1)*[1:n]+Sol(2);
data=[row_compress;corr_row].';

intervel=max(row_compress)-min(row_compress);
radius = 0.6*alpha*intervel;


[out,category] = mean_shift(radius, threshould, data);
 
category_num = size(out,1)
hold on; grid on;
categorys=cell(category_num,1);
centers=size(out);
for i=1:category_num
    tmp=data(find(category == i),:);
    categorys{i}=tmp;
    centers(i,1)=mean(tmp(:,1));
    centers(i,2)=mean(tmp(:,2));
end
figure(1)
scatter(data(:,1),data(:,2),80,'filled','o');
hold on

if category_num == 8
    category1 = data(find(category == 1),:);
    category2 = data(find(category == 2),:);
    category3 = data(find(category == 3),:);
    category4 = data(find(category == 4),:);
    category5 = data(find(category == 5),:);
    category6 = data(find(category == 6),:);
    category7 = data(find(category == 7),:);
    category8 = data(find(category == 8),:);
    scatter(category1(:,1),category1(:,2),50,[0.00,0.45,0.74],'filled');
    hold on
    scatter(category2(:,1),category2(:,2),50,[0.85,0.33,0.10],'filled');
    hold on
    scatter(category3(:,1),category3(:,2),50,[0.93,0.69,0.13],'filled');
    hold on
    scatter(category4(:,1),category4(:,2),50,[0.49,0.18,0.56],'filled');
    hold on
    scatter(category5(:,1),category5(:,2),50,[0.47,0.67,0.19],'filled');
    hold on
    scatter(category6(:,1),category6(:,2),50,[0.30,0.75,0.93],'filled');
    hold on
    scatter(category7(:,1),category7(:,2),50,[0.64,0.08,0.18],'filled');
    hold on
    scatter(category8(:,1),category8(:,2),50,'m','filled');
end
hold on
mkr='p';
sz=150;
figure(1)
s=scatter(centers(:,1),centers(:,2),sz,mkr,'MarkerFaceColor',[.1 .1 .1]);
L=legend(s,'Cluster Centers','fontsize',10);
grid on
category1 = data(find(category == 1),:);
rows=cell(category_num,1);

y=size(category_num,1);
for k=1:category_num
    rows{k}=find(category == k);
    y(k)=size(rows{k},1);
end
item = 0;
y(y==item) = []; 
y
end