function [val,time,x]=GRABGS_c(A,b,xe,kmax,TOL,alpha,tau)
[~,n]=size(A);
x=zeros(size(xe));
T=Pcolumn(tau,n);
disp(['** The block size of GRABGS_c with \alpha=',num2str(alpha),' is ',num2str(length(T)),' **'])
P=cell(1,size(T,2)-1);
for i=1:length(T)-1
    P{i}=T{i};
end
P=cell2mat(P).';
P_end=T{end}.';
%计算块的F范数
A2=size(length(T),1);
for j=1:length(T)
    A2(j)=norm(A(:,T{j}),'fro')^2;
end
delta_max2=size(length(T),1);
Ti=tic;
for j=1:length(T)
    [~,V,~]=svd(A(:,T{j}));
    V_max=max(diag(V).^2);
    delta_max2(j)=V_max(1);
end
mu=max(delta_max2);

AF=norm(A,'fro')^2;
I=eye(n,n);
ts=tic;
for iter=1:kmax
    I=eye(n,n);
    time(iter)=toc(ts);
    sk=A.'*(b-A*x);
    VAL=log(norm(x-xe)^2/norm(xe)^2);
    val(iter)=VAL;
    rk2=sk.^2;
    if size(P,1)==1
        rk_=sum(rk2(P));
    else
        rk_=sum(rk2(P),2);
    end
    rk2_block=[rk_;sum(rk2(P_end))];
    list=rk2_block./A2.';
    epsilonk=0.5*(max(list)+norm(sk)^2/norm(A,'fro')^2);
    Uk=find(list>=epsilonk);
    jk=randperm(length(Uk),1);
    j=Uk(jk);
    Jk=T{j};
    x=x+alpha*I(:,Jk)*(1/mu)*sk(Jk);
    if TOL>=VAL
        break
    end
end
end