close all
clear all
clc

m  = 128;
n  = 128;

xdannytmp = double(imread('HSTgray01.jpg','jpg'));
xdanny = xdannytmp(1:n,:);
xtr = reshape(xdanny,n*n,1);

% blur the image
gsigma = 1;
band =5;
A = blur(n,band,gsigma)+eps;
sum(sum(A>=10^-8))/(16384^2)
bblur = A*xtr;

% and put some noise to it
noiselevel=1e-2;


s=randn(n^2,1);
s = s/norm(s);
factor = noiselevel*norm(xtr);
bnoise = factor*s;
b = bblur + bnoise;  % blurred and noisy picture as vector
xblurnoise=reshape(b,n,n); % blurred and noisy picture as matrix
I=eye(n^2);
lambda=0.01;
In=sqrt(lambda).*I;
A=[A;In];
z=zeros(n^2,1);
b=[b;z];

kmax          =            1000;
TOL           =            -10;
tau           =            680;
delta=1;

[val_GRABGS_a01,time_GRABGS_a01,x_GRABGS_a01]=GRABGS_a(A,b,xtr,kmax,TOL,delta,tau);
%%
figure(1)
plot(val_GRABGS_a01, 'k+-','MarkerSize',13, 'LineWidth', 2, 'MarkerIndices', 1:floor(1000 / 6):1000)
LG=legend('GRABGS-a ($\delta$=1)');
LG.FontSize=14;
LG.Interpreter='latex';
xlabel('Iteration','Interpreter','latex','FontSize',13)
ylabel('ln(RSE)','Interpreter','latex','FontSize',13)
grid on
%
figure(2)
plot(time_GRABGS_a01,val_GRABGS_a01, 'k+-','MarkerSize',13, 'LineWidth', 2, 'MarkerIndices', 1:floor(1000 / 12):1000)
LG=legend('GRABGS-a ($\delta$=1)');
LG.FontSize=14;
LG.Interpreter='latex';
xlabel('CPU computing time','Interpreter','latex','FontSize',13)
ylabel('ln(RSE)','Interpreter','latex','FontSize',13)
grid on
xlim([0 180])

%%
figure(3)
imagesc(reshape(xtr,n,n));
colormap gray, axis image off

figure(4)
imagesc(reshape(xblurnoise,n,n));
colormap gray, axis image off

figure(5)
imagesc(reshape(x_GRABGS_a01,n,n));
colormap gray, axis image off
%%
xe=xtr;
SNR_GRABGS_a01=10*log10(sum(xe.^2)/sum((x_GRABGS_a01-xe).^2));
