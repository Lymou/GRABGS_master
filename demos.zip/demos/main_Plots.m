clear,clc;
close all
m           =          4000;
n           =          2000;


field = input("Please entry the linear system form (\n'0: Sparse & Consistant',\n'1: Sparse & Inconsistant'\n'2:Real sparse matrix collect'):");
switch field
    case str2double('0')
        
        density = 0.01;
        A = sprandn(m,n,density)+eps;
        for j = 1:n, A(:,j) = A(:,j)./norm(A(:,j)); end
        xe = randn(n,1);
        b = A*xe;
        disp(['==*** Creating a Test Problem with Consistent Sparse Linear System with density = ',...
            num2str(density*100),'% ***=='])
    case str2double('1')
        
        density = 0.01;
        A = sprandn(m,n,density)+eps;
        for j = 1:n, A(:,j)=A(:,j)./norm(A(:,j)); end
        xe = randn(n,1);
        b = A*xe;
        r1 = randn(m, 1);
        r = r1 - A * lsqminnorm(A, r1);
        r = r / norm(r);
        b = b + r;
        disp(['==*** Creating a Test Problem with Inconsistent Sparse Linear System with density = ',...
            num2str(density*100),'% ***=='])
    case str2double('2')
        
        addpath(genpath(pwd))
        load 'bibd_16_8'
        A = Problem.A+eps;
        if size(A,1) < size(A,2), A=A.'; end
        [m,n] = size(A);
        for j = 1:n, A(:,j) = A(:,j)./norm(A(:,j)); end
        xe = randn(n,1);
        b = A*xe;
        disp(['==*** Creating a Test Problem named "',...
            Problem.name,'" from Sparse Matrix Collection***=='])
    otherwise
        error('Unexpected field. No any system matrix A created!')
        
end

kmax                =             1000;
delta01             =             1;
delta02             =             1.85;
alpha01             =             1;
alpha02             =             1.85;
block               =             ceil((norm(A))^2);
tau                 =             floor(n/block);
TOL                 =             -10;

fprintf(1,'Perform kmax = %2.0f iterations with the GRABGS_c method.\n',kmax);
[val_GRABGS_c01, time_GRABGS_c01, x_GRABGS_c01] = GRABGS_c(A, b, xe, kmax, TOL,alpha01, tau);
fprintf(1,'Perform kmax = %2.0f iterations with the GRABGS_c method.\n',kmax);
[val_GRABGS_c02, time_GRABGS_c02, x_GRABGS_c02] = GRABGS_c(A, b, xe, kmax, TOL, alpha02, tau);
fprintf(1,'Perform kmax = %2.0f iterations with the GRABGS_a method.\n',kmax);
[val_GRABGS_a01, time_GRABGS_a01, x_GRABGS_a01] = GRABGS_a(A, b, xe, kmax, TOL, delta01, tau);
fprintf(1,'Perform kmax = %2.0f iterations with the GRABGS_a method.\n',kmax);
[val_GRABGS_a02, time_GRABGS_a02, x_GRABGS_a02] = GRABGS_a(A, b, xe, kmax, TOL, delta02, tau);


Fig01 = figure(1);
plot(val_GRABGS_c02,'m*-','LineWidth',2,'MarkerSize',11, 'MarkerIndices', 1:floor(length(val_GRABGS_c02) / 7):length(val_GRABGS_c02))
hold on
plot(val_GRABGS_a01,'kx-','LineWidth',2,'MarkerSize',12, 'MarkerIndices', 1:floor(length(val_GRABGS_a01) / 5):length(val_GRABGS_a01))
ylim([-10,0.1])
xlabel('Iteration','Interpreter','latex','FontSize',13)
ylabel('ln(RSE)','Interpreter','latex','FontSize',13)
LG=legend('GRABGS-c ($\alpha=1.85/\mu$)','GRABGS-a ($\delta$=1)');
set(LG,'FontSize',15,'Box','off','Interpreter','latex',...
    'Position',[0.631 0.746 0.256 0.155])
set(gca,'FontSize',12,'box', 'off')
xlabel('Iteration','Interpreter','latex','FontSize',15)
ylabel('ln(RSE)','Interpreter','latex','FontSize',15)


Fig02=figure(2);
plot(time_GRABGS_c02,val_GRABGS_c02,'m*-','LineWidth',2,'MarkerSize',11, 'MarkerIndices', 1:floor(length(val_GRABGS_c02) / 7):length(val_GRABGS_c02))
hold on
plot(time_GRABGS_a01,val_GRABGS_a01,'kx-','LineWidth',2,'MarkerSize',12, 'MarkerIndices', 1:floor(length(val_GRABGS_a01) / 5):length(val_GRABGS_a01))

ylim([-10,0.1])
xlabel('CPU computing time','Interpreter','latex','FontSize',15)
ylabel('ln(RSE)','Interpreter','latex','FontSize',15)
LG=legend('GRABGS-c ($\alpha=1.85/\mu$)','GRABGS-a ($\delta$=1)');
set(LG,'FontSize',15,'Interpreter','latex',...
    'Position',[0.631 0.746 0.256 0.155])
set(gca,'FontSize',12,'box', 'off')



count_GRABGS_c01 = size(val_GRABGS_c01, 2);
count_GRABGS_c02 = size(val_GRABGS_c02, 2);
count_GRABGS_a01 = size(val_GRABGS_a01, 2);
count_GRABGS_a02 = size(val_GRABGS_a02, 2);

disp('===================')
disp(['method', '     IT', '       CPU'])
disp(['GRABGS-c01', '    ', num2str(count_GRABGS_c01),  '      ', num2str(round(time_GRABGS_c01(end),4))])
disp(['GRABGS-c02', '    ', num2str(count_GRABGS_c02),  '      ', num2str(round(time_GRABGS_c02(end),4))])
disp(['GRABGS-a01', '    ', num2str(count_GRABGS_a01),  '      ', num2str(round(time_GRABGS_a01(end),4))])
disp(['GRABGS-a02', '    ', num2str(count_GRABGS_a02),  '      ', num2str(round(time_GRABGS_a02(end),4))])
disp('===================')
disp(['Cond(A)=',num2str(cond(A))])
disp(['\|A\|_2^2=',num2str(norm(A)^2)])
disp(['densty=',num2str((sum(sum(A>=1e-10))/(m*n))*100),'%'])

Fig03=figure(3);
delta=1;
t=norm(A)^2;
tau=[floor(n/2),floor(n/t),floor(n/8),floor(n/25),floor(n/40)];
[val,time,~]=GRABGS_a(A,b,xe,kmax,TOL,delta,tau(1));
plot(time,val,'rs-','MarkerSize',8,'LineWidth',1.5,'MarkerIndices', 1:floor(length(val) / 10):length(val))
hold on
[val,time,~]=GRABGS_a(A,b,xe,kmax,TOL,delta,tau(2));
plot(time,val,'b*-','MarkerSize',10,'LineWidth',1.5,'MarkerIndices', 1:floor(length(val) / 8):length(val))
hold on
[val,time,~]=GRABGS_a(A,b,xe,kmax,TOL,delta,tau(3));
plot(time,val,'rp-','MarkerSize',8,'LineWidth',1.5,'MarkerIndices', 1:floor(length(val) / 10):length(val))
hold on
[val,time,~]=GRABGS_a(A,b,xe,kmax,TOL,delta,tau(4));
plot(time,val,'rd-','MarkerSize',8,'LineWidth',1.5,'MarkerIndices', 1:floor(length(val) / 10):length(val))
hold on
[val,time,~]=GRABGS_a(A,b,xe,kmax,TOL,delta,tau(5));
plot(time,val,'rx-','MarkerSize',11,'LineWidth',1.5,'MarkerIndices', 1:floor(length(val) / 10):length(val))

LG=legend('t=2','t=$\big\lceil \|A\|^2_2 \big\rceil$','t=8','t=25','t=40');
set(LG,'FontSize',15,'Box','off','Interpreter','latex',...
    'Position',[0.631 0.746 0.256 0.155])
set(gca,'FontSize',12,'box', 'off')
xlabel('CPU computing time','Interpreter','latex','FontSize',15)
ylabel('ln(RSE)','Interpreter','latex','FontSize',15)
ylim([-10 .1])


Fig04=figure(4);
alpha=1.85;
t=norm(A)^2;
tau=[floor(n/2),floor(n/t),floor(n/8),floor(n/25),floor(n/40)];
[val,time,~]=GRABGS_c(A,b,xe,kmax,TOL,alpha,tau(1));
plot(time,val,'ms-','MarkerSize',8,'LineWidth',1.5,'MarkerIndices', 1:floor(length(val) / 10):length(val))
hold on
[val,time,~]=GRABGS_c(A,b,xe,kmax,TOL,alpha,tau(2));
plot(time,val,'k*-','MarkerSize',10,'LineWidth',1.5,'MarkerIndices', 1:floor(length(val) / 8):length(val))
hold on
[val,time,~]=GRABGS_c(A,b,xe,kmax,TOL,alpha,tau(3));
plot(time,val,'mp-','MarkerSize',8,'LineWidth',1.5,'MarkerIndices', 1:floor(length(val) / 10):length(val))
hold on
[val,time,~]=GRABGS_c(A,b,xe,kmax,TOL,alpha,tau(4));
plot(time,val,'md-','MarkerSize',8,'LineWidth',1.5,'MarkerIndices', 1:floor(length(val) / 10):length(val))
hold on
[val,time,~]=GRABGS_c(A,b,xe,kmax,TOL,alpha,tau(5));
plot(time,val,'mx-','MarkerSize',11,'LineWidth',1.5,'MarkerIndices', 1:floor(length(val) / 10):length(val))
hold on
LG=legend('t=2','t=$\big\lceil \|A\|^2_2 \big\rceil$','t=8','t=25','t=40');
set(LG,'FontSize',15,'Interpreter','latex',...
    'Position',[0.631 0.746 0.256 0.155])
set(gca,'FontSize',12,'box', 'off')
xlabel('CPU computing time','Interpreter','latex','FontSize',15)
ylabel('ln(RSE)','Interpreter','latex','FontSize',15)
ylim([-10 .1])

