clear,clc;
n=1024;
disp(['==*** Creating a Phillips Test Problem with n= ',num2str(n),' ***=='])
disp(['=========================================================='])
[A,b,xe] = phillips(n);

I=eye(n);
lambda=0.01;
In=sqrt(lambda).*I;
A=[A;In];
sigma = 0.01;
noise_norm = norm(b, 'fro') * sigma;
e = randn(size(b));
e = e / norm(e, 'fro') * noise_norm;
b = b + e;
z=zeros(n,1);
b=[b;z];

kmax = 5000;

delta01=1;
delta02=1.85;
alpha01=1;
alpha02=1.85;
t=(norm(A))^2;
tau=floor(n/3.6);
TOL=-7;

%%
fprintf(1,'Perform kmax = %2.0f iterations with the GRABGS_c method with alpha=1.85/mu.\n',kmax);
[val_GRABGS_c02,time_GRABGS_c02,x_GRABGS_c02]=GRABGS_c(A,b,xe,kmax,TOL,alpha02,tau);
fprintf(1,'Perform kmax = %2.0f iterations with the GRABGS_a method with alpha=1.\n',kmax);
[val_GRABGS_a01,time_GRABGS_a01,x_GRABGS_a01]=GRABGS_a(A,b,xe,kmax,TOL,delta01,tau);

%%
figure(1)

% plot(xe, 'go-','MarkerSize',10, 'LineWidth', 8, 'MarkerIndices', 1:floor(n / 6):n)
plot(xe, 'g-', 'LineWidth', 7)
hold on
plot(x_GRABGS_c02, 'm*--','MarkerSize',13, 'LineWidth', 3, 'MarkerIndices', 1:floor(n / 6)+400:n)
hold on
plot(x_GRABGS_a01, 'k+--','MarkerSize',13, 'LineWidth', 3, 'MarkerIndices', 1:floor(n / 6)+500:n)
LG=legend('Exact Solution','GRABGS-c ($\alpha_k=1.85/\mu$)','GRABGS-a ($\delta$=1)');
LG.FontSize=10;
LG.Interpreter='latex';
LG.Box='off';
grid on
xlim([0 1200])
ylim([-.02 0.25])

%%

count_GRABGS_c02 = size(val_GRABGS_c02, 2);
count_GRABGS_a01 = size(val_GRABGS_a01, 2);

disp('===================')
disp(['method', '     ln(RSE)', '       CPU','         IT'])
disp(['GRABGS-c02', '    ', num2str(val_GRABGS_c02(end)),  '      ', num2str(round(time_GRABGS_c02(end),4)),'         ', num2str(count_GRABGS_c02)])
disp(['GRABGS-a01', '    ', num2str(val_GRABGS_a01(end)),  '      ', num2str(round(time_GRABGS_a01(end),4)),'         ', num2str(count_GRABGS_a01)])
disp('===================')
disp(['Cond(A)=',num2str(cond(A))])
disp(['\|A\|_2^2=',num2str(norm(A)^2)])
%%
sum(sum(A>=10^-8))/(2048*n)

SNR_GRABGS_c02=10*log10(sum(xe.^2)/sum((x_GRABGS_c02-xe).^2))
SNR_GRABGS_a01=10*log10(sum(xe.^2)/sum((x_GRABGS_a01-xe).^2))